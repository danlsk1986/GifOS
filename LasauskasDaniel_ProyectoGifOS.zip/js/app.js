//Variables


var estilo = document.querySelector('#estilo');
let opcTemas = document.querySelector('.opc-tema');
let header = document.querySelector('header');
let btnTema = document.querySelector('.btn-tema');
let btnCrea = document.querySelector('.btn-crea');




let cajaHistorial = document.querySelector('.history');
var btnHistorial = document.getElementsByClassName('btnHistory');




var contador = 0;





//Buscar

let campoBusqueda = document.querySelector('.busqueda');
let valorBusqueda = document.querySelector('#valor');
let searchBtn = document.querySelector('#main-btn');
let opcBusqueda = document.querySelector('.opc-busqueda');
let enviar = document.querySelector('#enviar');
var elementos = document.querySelector('#elem');
var resBusqueda = document.querySelector('.resBusqueda');
var valor = document.querySelector('#valor');



//Sugerencias

let rowSuggestions = document.querySelector('.filaSugerencias');
var btnCaja = document.getElementsByClassName('btnCaja');
var misSugerencias = ['simpsons', 'star wars', 'cartoon network', 'divertidos'];

//Arrays

var listaSearch = [];
var listaTrending = [];
var misBusquedas = [];
var listaSug = [];
var listaTitulos = [];
var guardarHistorial = [];









//Event Listeners



window.addEventListener('load', function () {

  mostrarSugerencias();
  tendenciasFetch();
  mostrar();
  verBtnHistorial();



})


enviar.addEventListener('click', function () {

  let busqueda = valor.value;

  if (valorBusqueda.value != "") {
    valorBusqueda.value = "";
  }

  if (busqueda == "") {
    alert('Por favor ingrese una busqueda..')
  } else {
    

    
    searchFetch(busqueda);
    mostrarLocalStorage(busqueda);
    verBtnHistorial();

  }

  

});



valorBusqueda.addEventListener('keyup', keyUpCampo);

btnTema.addEventListener('click', headerChange);

opcTemas.addEventListener('click', cambioTemas);



//FUNCIONES

function mostrar(){
    
  let largo = localStorage.length;

  for( var i = 1 ; i <= largo; i++){
    crearBtnHistorial(localStorage[i])          
  }
      
}


function mostrarLocalStorage(busqueda) {


  if (localStorage.length == 0) {

    contador += 1;
    localStorage.setItem(contador, busqueda);
    guardarHistorial.push(localStorage.getItem(contador));
    crearBtnHistorial(busqueda);

  } else {
    contador = localStorage.length
    contador += 1;
    localStorage.setItem(contador, busqueda);
    guardarHistorial.push(localStorage.getItem(contador));
    crearBtnHistorial(busqueda);
  }



}



//CAMBIA EL TEMA EN BASE AL BOTON PRESIONADO

function cambioTemas(e) {

  let temaActual = e.target.value;

  if (temaActual == "Sailor Night") {
    estilo.setAttribute('href', 'css/sailorNight.css');
  }
  else {
    estilo.setAttribute('href', 'css/sailorDay.css');
  }

}


//EL HEADER  AMPLIA EL HEIGHT EN BASE A MOSTRAR LOS BOTONES DE CAMBIO DE TEMA

function headerChange() {

  if (header.style.height == "210px") {
    header.style = 'height: 130px';
    opcTemas.style = 'display: none';

  } else {
    header.style = 'height: 210px';
    opcTemas.style = "position: absolute;top: 36px;background-color: #e6e6e6; width:163px; height: 102px;display:flex; align-items: center;justify-content: center;flex-direction: column;";
  }
}


//LLAMA A LAS FUNCIONES QUE DEBEN EJECUTARSE ON KEY UP

function keyUpCampo() {


  //remueve el attrbute disabled
  enviar.removeAttribute('disabled');

  

  //llama a la funcion
  normalToActive();

  //Elimina todos los datos del array lista
  listaSearch.splice(0, listaSearch.length);

  
  

}

//REMUEVE LA CLASE INDICADA
function normalToActive() {
  enviar.classList.remove('normal');
  enviar.classList.add('activa');

}






//FUNCIONES FETCH


//LLAMA AL ENDPOINT SEARCH DE GIPHY

function searchFetch(url) {

  fetch(`http://api.giphy.com/v1/gifs/search?q=${url}&api_key=5bIrA5CGCfUFE7P8FWJez1t14xzWVJAF&limit=12`)
    .then(function (res) {

      if (res.ok) {
        return res.json();

      } else {
        throw "Error en la llamada";
      }

    })
    .then(function (json) {

      for (j in json.data) {
        let resultado = json.data[j].images.downsized.url;

        listaSearch.push(resultado);

      }

      if (url == "") {
        alert('Por favor ingrese una busqueda..')
      } else {

        elementos.innerHTML = `

          <input type="text" placeholder=" Resultado de la Busqueda">
  
          <div class="fila_1">
            <div class="caja"><img src=${listaSearch[0]}></div>
            <div class="caja"><img src=${listaSearch[1]}></div>
            <div class="caja"><img src=${listaSearch[2]}></div>
            <div class="caja"><img src=${listaSearch[3]}></div>        
          </div>
  
          <div class="fila_2">
            <div class="caja"><img src=${listaSearch[4]}></div>
            <div class="caja"><img src=${listaSearch[5]}></div>
            <div class="caja"><img src=${listaSearch[6]}></div>
            <div class="caja"><img src=${listaSearch[7]}></div> 
          </div>
  
          <div class="fila_3">
            <div class="caja"><img src=${listaSearch[8]}></div>
            <div class="caja"><img src=${listaSearch[9]}></div>
            <div class="caja"><img src=${listaSearch[10]}></div>
            <div class="caja"><img src=${listaSearch[11]}></div>       
          </div> `;
      }



    })


    .catch(function (error) {
      alert(error);
    })
}



//LLAMA A LOR 4 VALORES DENTRO DEL ARRAY MIS SUGERENCIAS

function mostrarSugerencias() {
  for (x in misSugerencias) {
    let url = `http://api.giphy.com/v1/gifs/search?q=${misSugerencias[x]}&api_key=5bIrA5CGCfUFE7P8FWJez1t14xzWVJAF&limit=1`;

    sugerenciasFetch(url);
  }


}



//AGREGA UNA ESCUCHA A LOS 4 BOTONES DE VER MAS Y LLAMA LA BUSQUEDA SEGUN SU ID

function botonCaja() {

  let verMas = Array.from(btnCaja)
  for (i in verMas) {
    //verMas[i].setAttribute('id', listaTitulos[i])
    verMas[i].addEventListener('click', function () {

      if (listaSearch == "") {
        searchFetch(this.id)
      } else {
        listaSearch.splice(0, listaSearch.length);
        searchFetch(this.id)
      }

    })
  }

}






function sugerenciasFetch(url) {

  fetch(url)
    .then(function (res) {

      if (res.ok) {
        return res.json();

      }
      else {
        throw 'Error en Sugerencias'
      }
    })



    .then(function (json) {


      for (x in json.data) {        

        let resultado = json.data[x].images.downsized.url;
        let titulo = json.data[x].title;
        
        let divisiones = titulo.split(" ", 2);
        let titulo2 = divisiones.join(' ');
        
        
        listaTitulos.push(titulo2);
        listaSug.push(resultado);
        

      }




      rowSuggestions.innerHTML =
        `
          <div class="caja">
          <span class="linea">#${listaTitulos[0]}
          <img class="close" src="img/button close.svg" alt="close"></span>
          <img src=${listaSug[0]}>
          <button class="btnCaja" id="${listaTitulos[0]}">Ver más...</button>
          </div>
          <div class="caja">
          <span class="linea">#${listaTitulos[1]}
          <img class="close" src="img/button close.svg" alt="close"></span>
          <img src=${listaSug[1]}>
          <button class="btnCaja" id="${listaTitulos[1]}">Ver más...</button> 
          </div>

          <div class="caja">
          <span class="linea">#${listaTitulos[2]}
          <img class="close" src="img/button close.svg" alt="close"></span>
          <img src=${listaSug[2]}>
          <button class="btnCaja" id="${listaTitulos[2]}">Ver más...</button> 
          </div>

          <div class="caja">
          <span class="linea">#${listaTitulos[3]}
          <img class="close" src="img/button close.svg" alt="close"></span>
          <img src=${listaSug[3]}>
          <button class="btnCaja" id="${listaTitulos[3]}">Ver más...</button> 
          </div> `



      botonCaja();


    })

    .catch(function (error) {
      console.log(error);

    })


}










function crearBtnHistorial(busqueda) {

  var newButton = document.createElement("button");
  var valueButton = document.createTextNode(busqueda);
  newButton.appendChild(valueButton);  
  newButton.setAttribute('class', 'btnHistory');
  cajaHistorial.appendChild(newButton);

}



function verBtnHistorial() {
  let btnHistory = Array.from(btnHistorial);
  for (a in btnHistory) {
    btnHistory[a].addEventListener('click', function (e) {

      if (listaSearch == "") {
        searchFetch(this.innerText);
      } else {
        listaSearch.splice(0, listaSearch.length);
        searchFetch(this.innerText);
      }


    })
  }

}




















function tendenciasFetch() {

  let url = 'https://api.giphy.com/v1/gifs/trending?api_key=5bIrA5CGCfUFE7P8FWJez1t14xzWVJAF&limit=10';

  let fila1 = document.querySelector('.fila_1');
  let fila2 = document.querySelector('.fila_2');
  let fila3 = document.querySelector('.fila_3');

  fetch(url)
    .then(function (res) {

      if (res.ok) {
        return res.json();
      }
      else {
        throw 'Error en Sugerencias'
      }
    })

    .then(function (json) {

      for (k in json.data) {
        let resultado = json.data[k].images.downsized.url;
        listaTrending.push(resultado);
      }


      fila1.innerHTML = `
                        <div class="caja"><img src=${listaTrending[0]}></div>
                        <div class="caja"><img src=${listaTrending[1]}></div>
                        <div class="caja"><img src=${listaTrending[2]}></div>
                        <div class="caja"><img src=${listaTrending[3]}></div> `;

      fila2.innerHTML = `
                        <div class="caja_grande"><img src=${listaTrending[4]}></div>
                        <div class="caja"><img src=${listaTrending[5]}></div>
                        <div class="caja"><img src=${listaTrending[6]}></div> `;

      fila3.innerHTML = `
                        <div class="caja"><img src=${listaTrending[7]}></div>
                        <div class="caja"><img src=${listaTrending[8]}></div>
                        <div class="caja_grande"><img src=${listaTrending[9]}></div>`;
    })

    .catch(function (error) {
      console.log(error);

    })

}





